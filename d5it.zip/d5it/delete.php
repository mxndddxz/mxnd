<html lang="en">
<head>
  <title>ลบข้อมูล</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<?php /* *** No Copyright for Education (Free to Use and Edit) *** * /
PHP 7.1.1 | MySQL 5.7.17 | phpMyAdmin 4.6.6 | by appserv-win32-8.6.0.exe
Created by Mr.Earn SURIYACHAY | ComSci | KMUTNB | Bangkok | Apr 2018 */ ?>
<html>

<body>

  <?php
  require('connect.php');

  $sql = '
    SELECT * 
    FROM tb_d5_67;
    ';

  $objQuery = mysqli_query($conn, $sql) or die("Error Query [" . $sql . "]");
  ?>
  <div class="container mt-3">
 <table class="table table-bordered">
 <thead class="table-Danger">              
    <?php
    $i = 1;
    while ($objResult = mysqli_fetch_array($objQuery)) {
    ?>
      <tr>
        <td>
          <div align="center"><?php echo $i; ?></div>
        </td>
        <td><?php echo $objResult["std_id"]; ?></td>
        <td><?php echo $objResult["n_title"]; ?></td>
        <td><?php echo $objResult["f_name"]; ?></td>
        <td><?php echo $objResult["l_name"]; ?></td>
        <td><?php echo $objResult["n_name"]; ?></td>
        <td><?php echo $objResult["number"]; ?></td>
        <td><?php echo $objResult["DepartmentID"]; ?></td>
        
        <td align="center"><a href="deletedata.php?std_id=<?php echo $objResult["std_id"]; ?>"><button type="button" class="btn btn-danger">ลบข้อมูล</button></a></td>
      </tr>
</div>
    <?php
      $i++;
    }
    ?>
</thead>

  </table>
</table>
</body>
</html>