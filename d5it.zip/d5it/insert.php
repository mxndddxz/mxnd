<html lang="en">
<head>
  <title>เพิ่มข้อมูลนักศึกษา</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
 
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <link rel="stylesheet" href="css\mxndd.css">
</head>
<?php /* *** No Copyright for Education (Free to Use and Edit) *** * /
PHP 7.1.1 | MySQL 5.7.17 | phpMyAdmin 4.6.6 | by appserv-win32-8.6.0.exe
Created by Mr.Earn SURIYACHAY | ComSci | KMUTNB | Bangkok | Apr 2018 */ ?>
<html>

<head></head>

<body>
    <h2>เพิ่มข้อมูลนักศึกษา</h2>
    <style>
      h2 {
        text-align: center;
      }
    </style>
    <form action="insertdata.php" method="post" name="tb_d5_67">
    <div class="container mt-3">
<table class="table table-bordered">
<thead class="table-Danger">   
            <tr>
                <td>รหัสนักศึกษา : </td>
                <td><input type="text" name="std_id"></td>
            </tr>
            <tr>
                <td>คำนำหน้า : </td>
                <td><input type="text" name="n_title"></td>
            </tr>
            <tr>
                <td>ชื่อ : </td>
                <td><input type="text" name="f_name"></td>
            </tr>
            <tr>
                <td>สกุล : </td>
                <td><input type="text" name="l_name"></td>
            </tr>
            <tr>
                <td>ชื่อเล่น : </td>
                <td><input type="text" name="n_name"></td>
            </tr>
            <tr>
                <td>เพศ : </td>
                <td><input type="text" name="sex"></td>
            </tr>
            <tr>
                <td>เเผนก : </td>
                <td><input type="text" name="DepartmentID"></td>
            </tr>
            <tr>
                <td>เบอร์ : </td>
                <td><input type="text" name="number"></td>
            </tr>
            <tr>
                <td>อีเมล์ : </td>
                <td><input type="text" name="e_mail"></td>
            </tr>
            
            
        </table>
        <br>
        <input type="submit" value="เสร็จสิ้น">
    </form>
</thead> 
</body>

</html>
