<?php 
    session_start();
?>

<!DOCTYPE html>
<html lang="th">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="nn.css">
    <title>เว็บไซต์ของฉัน</title>
    <style>
        body, html {
            margin: 0;
            padding: 0;
            height: 100%;
            font-family: Arial, sans-serif;
            color: white;
            background:url(https://data.1freewallpapers.com/download/girl-glance-gloomy-anime-1280x960.jpg)  no-repeat center center fixed; 
     background-size: cover;
        }


        .content {
            position: relative;
            z-index: 1;
            padding: 20px;
        }


        .navbar a, .dropdown button {
            color: white;
            text-decoration: none;
            padding: 10px 20px;
            display: inline-block;
        }

        .navbar a:hover, .dropdown button:hover {
            background-color: rgba(255, 255, 255, 0.2);
            border-radius: 5px;
        }

        .dropdown {
            position: relative;
            display: inline-block;
        }

        .dropdown-content {
            display: none;
            position: absolute;
            background-color: rgba(0, 0, 0, 0.8);
            min-width: 160px;
            box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);
            z-index: 1;
            border-radius: 5px;
            overflow: hidden;
        }

        .dropdown-content a {
            color: white;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
        }

        .dropdown-content a:hover {
            background-color: rgba(255, 255, 255, 0.1);
        }

        .dropdown:hover .dropdown-content {
            display: block;
        }

        .nav-item {
            list-style-type: none;
            display: flex;
            align-items: center;
        }

        .nav-item a {
            padding: 10px 20px;
            color: white;
            text-decoration: none;
        }

        .nav-item a:hover {
            background-color: rgba(255, 255, 255, 0.2);
            border-radius: 5px;
        }

        .navbar img {
            border-radius: 50%;
            border: 2px solid white;
            margin-right: 30px;
        }
    </style>
</head>
<body>
    <div class="content">
        <div class="navbar">
            <div>
                <a href="#home">หน้าหลัก</a>
                <a href="select.php">รายชื่อนักเรียน</a>
                <a href="insert.php">เพิ่มข้อมูล</a>
                <a href="update.php">แก้ไขข้อมูล</a>
                <a href="index4.php">ค้นหารายชื่อนักศึกษา</a>
            </div>
            <div class="nav-item">
                <a href="mind.php">
                    <img src="cc.jpg" alt="Trulli" width="50px" height="50px">
                </a>
                <a href="logout.php">ออกจากระบบ</a>
            </div>
        </div>
    </div>
</body>
</html>