<!DOCTYPE html>
<html
</head>
<title>ประวัติส่วนตัว</title>
<meta charset="UTF-8"
<meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body style="background-color: #17ba66;"
<div class="container-fluid p-5 bg-primary text-white text-center"></div>
<div class="container mt-5"></div>
<h2>แนะนำตัว</h2>
<img src="im.jpg" alt="Tk" width="270" height="320">
<h1>ชื่อ นาย ธีรภัทร คำหงษา</h1>
<h2>ชื่อเล่น อิ่ม </h2>
<h2>อายุ 18 </h3>
<h2>กรุ๊ปเลือด A </h4>
<h2 = style="color: brown;">ว/ด/ป ของฉัน
<h2>เกิด:18 พฤศจิกายน พ.ศ. 2548 </h5>
<h2 = style="color: brown;">ที่อยู่
<h2></h2>221/2 หมู่ 4 บ้านโนนสาทร ต.เมือง อ.เมือง จ.ชัยภูมิ </h2>
<h2 = style="color: brown;">ช่องทางการติดต่อ
<h2>Facebook:Thiraphat Tk 
<h2>Instagram:im_.tk18</h2>
<h2>Line:thiraphat2005</h2>
<h2>เบอร์โทร:061-284-4292</h2>
<h2 = style="color: brown;">ข้อมูลส่วนตัว</h2>
<h2>-ชื่อบิดา:นายธีระพล คำหงษา อายุ 39 ปี</h1>
<h2>อาชีพ:ช่าง เบอร์โทร:095-749-4922
<h2>-ชื่อมารดา:นางจุฑารัตน หลวงกอง อายุ 40 ปี</h2>
<h2>อาชีพ:ผู้ช่วย เบอร์โทร:095-175-9090</h2>
<h2 = style="color: brown;">งานอดิเรก</h2>
<h2>-เล่นเกม ฟังเพลง ดูหนัง</h2>
<h2 = style="color: brown;">เรียนจบอยากทำอาชีพอะไร</h2>
<h2>-อยากรับราชการ</h2>
</body>
</html>