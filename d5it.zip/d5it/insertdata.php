<?php /* * No Copyright for Education (Free to Use and Edit) * * /
PHP 7.1.1 | MySQL 5.7.17 | phpMyAdmin 4.6.6 | by appserv-win32-8.6.0.exe
Created by Mr.Earn SURIYACHAY | ComSci | KMUTNB | Bangkok | Apr 2018 */ ?>
<?php
require('connect.php');

$std_id              = $_REQUEST['std_id'];
$n_title             = $_REQUEST['n_title'];
$f_name              = $_REQUEST['f_name'];
$l_name              = $_REQUEST['l_name'];
$n_name              = $_REQUEST['n_name'];
$sex                 = $_REQUEST['sex'];
$DepartmentID        = $_REQUEST['DepartmentID'];
$number              = $_REQUEST['number'];
$e_mail              = $_REQUEST['e_mail'];

$sql = "
 INSERT INTO tb_d5_67 (std_id, n_title, f_name, n_name, l_name, sex, DepartmentID, number, e_mail)
 VALUES ('$std_id','$n_title','$f_name','$n_name','$l_name','$sex','$DepartmentID','$number','$e_mail');
";

 $objQuery = mysqli_query($conn, $sql);

 if ($objQuery) {
  echo "เพิ่มข้อมูลเสร็จแล้ว";
 } else {
  echo "Error: Input";
 }

mysqli_close($conn); // ปิดการเชื่อมต่อฐานข้อมูล
echo "<br><br>";
?>
